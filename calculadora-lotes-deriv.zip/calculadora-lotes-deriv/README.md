# Calculadora de Lotes Deriv

Calculadora automática para determinar o tamanho de lote ideal nos índices sintéticos da Deriv.

## Como usar

1. Insira seu saldo em conta
2. Defina a porcentagem de risco
3. Insira o número de pontos de Stop Loss
4. Defina o valor por ponto do ativo
5. Clique em "Calcular" para obter o lote ideal

---

Desenvolvido por **Guardianfx0**
Licenciado sob a GPL v3.
